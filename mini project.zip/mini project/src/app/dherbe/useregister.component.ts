import { Component, OnInit } from '@angular/core';
import { ProductserviceService } from './productservice.service';
import { Router } from '../../../node_modules/@angular/router';

@Component({
  selector: 'app-useregister',
  templateUrl: './useregister.component.html',
  styleUrls: ['./useregister.component.css']
})
export class UseregisterComponent implements OnInit {
  result = 'male';
 show=false;
  role='Admin';
  role1='SuperUser';
  role2='Cashier';

  constructor(private service1:ProductserviceService,private router:Router){}
model:any={}
value1:String
addUser(roles:any):any{
    console.log(this.model);
    console.log(roles);
    if(roles==this.role){
      this.show=true;
    }else if(roles==this.role1){
      this.show=true;
    }
    else if(roles==this.role2){
      this.show=true;
    }
  
  else{
    this.router.navigate(['/userlogin']);
  }
  this.service1.addUserRegister(this.model).subscribe();
 
}
ngOnInit(){

}


}
