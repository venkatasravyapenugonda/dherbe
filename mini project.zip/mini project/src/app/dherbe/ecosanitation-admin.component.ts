import { Component, OnInit } from '@angular/core';
import { ProductserviceService } from './productservice.service';
import { Sanitation } from './sanitation.interface';
import { Router } from '../../../node_modules/@angular/router';

@Component({
  selector: 'app-ecosanitation-admin',
  templateUrl: './ecosanitation-admin.component.html',
  styleUrls: ['./ecosanitation-admin.component.css']
})
export class EcosanitationAdminComponent implements OnInit {
  proddata:any[]=[];
 prodata:any[]=[];
  prodname:String;
  pros:any;
selectedFiles:FileList;
 currentFileUpload:File;
 dataone:any[];
 result=false;
  constructor(private service:ProductserviceService,private router:Router) { }
  selectFile(event){
    this.selectedFiles=event.target.files;
  }
  upload(){
    this.currentFileUpload=this.selectedFiles.item(0);
    this.service.saveProfile(this.currentFileUpload).subscribe(event=>{
  });
  this.selectedFiles=undefined;
 } 
  getdata(){
   console.log("haiii");
   this.service.getdata().subscribe((data:any)=>this.proddata=data);
   this.result=true;
 } 
 ngOnInit(){
    this.service.getdata().subscribe((data:any)=>this.proddata=data);
 }
 deletebutton1(data:any){
  console.log(data);
  let index=this.prodata.indexOf(data);
  this.prodata.splice(index,1);
  this.service.deleteSanitationProduct(data).subscribe();
}
updateButton1(data):any{
 this.router.navigate(['/updateSanitation']);
}
}
 /*  model:any={};  //model is the obj that accepts the data of employee id,name,salary
  model1:any={};  //model is the obj that accepts the data of employee id,name,salary
  model2:any={};
  addProduct(model):any{
    console.log(this.model);
    this.Service.addProduct(this.model).subscribe();
  }
 
  updateProduct(model1):any{
    console.log(this.model1);
    this.Service.updateSanitationProduct(this.model1).subscribe();
  }

  GoBack(){
    this.router.navigate(['/ecosanitation']);
  }
  
  constructor(private Service:ProductserviceService,private router:Router) { }
 
  ngOnInit() {
  }
  reloadData(){
    this.Service.getAllProducts().subscribe((data:any)=>this.model2=data);

  }

  deletebutton1(model: String) {
    //console.log(id);
    this.Service.deleteSanitationProduct(model)
      .subscribe(data => {console.log(data);
        this.reloadData();
        })
        }

}
 */
 

