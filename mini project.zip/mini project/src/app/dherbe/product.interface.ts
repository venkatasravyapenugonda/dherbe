export interface product{
    prodid:number;
    prodname:String;
    prodprice:number;
    proddesc:{
        stock:string;
        weight:number;
        guidelines:string;
        edate:Date;
    }
}