import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-dummy-list',
  templateUrl: './dummy-list.component.html',
  styleUrls: ['./dummy-list.component.css']
})
export class DummyListComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
