package com.cg.product.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.cg.product.dto.DherbeSanitation;
import com.cg.product.dto.UserRegister;
import com.cg.product.service.DherbeUserRegisterService;

@RestController
@RequestMapping("/userregister")
@CrossOrigin(origins="http://localhost:4200")
public class DherbeUserRegisterController {
	@Autowired
	DherbeUserRegisterService dherbeUserRegisterService;
	@PostMapping("/adduser")
	public ResponseEntity<UserRegister> addProduct(@RequestBody UserRegister user) {
		UserRegister data=dherbeUserRegisterService.addNewUser(user);
		if(data==null) {
			return new ResponseEntity("data not added",HttpStatus.NOT_FOUND);
		}
		return new ResponseEntity<UserRegister>(user,HttpStatus.OK);
	}
	
	@GetMapping("/validate/{mob}/{password}")
	public boolean login(@PathVariable("mob") Long mobile,@PathVariable("password") String password){
		return dherbeUserRegisterService.validateUserLogin(mobile, password);
		}
	
	
	@GetMapping("/getProductByMobileandanswer/{mob}/{ans}")
	public boolean validMobileandAnswer(@PathVariable("mob") Long mobile,@PathVariable("ans") String answer){
		return dherbeUserRegisterService.validateMobileandAnswer(mobile, answer);
		}
	
	@PutMapping("/confirmPassword/{mob}/{pwd}")
	public void confirmNewPassword(@PathVariable("mob") Long mobile,@PathVariable("pwd") String password){
		System.out.println(password); 
		dherbeUserRegisterService.updatepassword(mobile, password);
		}
	
	@GetMapping("/admindetails/{mob}/{password}")
	public Integer getAdminndSuperUserDetails(@PathVariable("mob") Long mobile,@PathVariable("password") String password){
		 String role=dherbeUserRegisterService.getAdminndSuperUserDetails(mobile, password);
		 System.out.println(mobile);
		 System.out.println("controller"+role);
		 if(role.equals("Admin")) {
			 return 1;
		 }
		 else if(role.equals("Customer")) {
			 return 2;
		}
	return 3;
}
	@DeleteMapping("/deleteUser/{mobId}")
	public void deleteUser(@PathVariable("mobId") Long mobile) {
		System.out.println("deleted"+mobile);
		dherbeUserRegisterService.deleteUser(mobile);
	}
	
	@GetMapping("/getalluserdetails")
	public ResponseEntity<List<UserRegister>> getAllUserDetails() {
		List<UserRegister> myList=dherbeUserRegisterService.getAllUserDeatils();
		if(myList.isEmpty()) {
			return new ResponseEntity("No user found",HttpStatus.NOT_FOUND);
			
		}
		return new ResponseEntity(myList,HttpStatus.OK);
	}


}
