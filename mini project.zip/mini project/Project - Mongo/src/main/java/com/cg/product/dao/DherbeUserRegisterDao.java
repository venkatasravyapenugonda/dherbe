package com.cg.product.dao;

import java.util.List;

import com.cg.product.dto.UserRegister;

public interface DherbeUserRegisterDao{
	public boolean validateMobileandAnswer(Long mobileno, String answer);
	public boolean validateUserLogin(Long mobile, String password); 
	public UserRegister addNewUser(UserRegister user);
	public void updatepassword(Long mobile, String pwd);
	public String getAdminndSuperUserDetails(Long mobile, String password);
	public List<UserRegister> getAllUserDeatils();
	public void deleteUser(Long mobileNo); 
	

}

