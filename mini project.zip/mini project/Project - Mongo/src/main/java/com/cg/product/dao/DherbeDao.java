package com.cg.product.dao;

import java.util.List;

import com.cg.product.dto.DherbeBeauty;
import com.cg.product.dto.DherbeSanitation;


public interface DherbeDao  {
	public List<DherbeBeauty> showAllProducts();
	public DherbeBeauty saveProduct(DherbeBeauty dherbebeauty);
	public DherbeBeauty searchByProductId(int proId);
	public void deleteProduct(String proId); 
	public DherbeBeauty updateProduct(String proid,String price,String stock);
	
	
}
