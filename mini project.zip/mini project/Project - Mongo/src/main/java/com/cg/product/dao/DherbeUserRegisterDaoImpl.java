package com.cg.product.dao;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.stereotype.Repository;

import com.cg.product.dto.DherbeBeauty;
import com.cg.product.dto.UserRegister;

@Repository
public class DherbeUserRegisterDaoImpl implements DherbeUserRegisterDao {
	@Autowired
	MongoTemplate mongoTemplate;
	@Override
	public UserRegister addNewUser(UserRegister user) {
		
		System.out.println(user.getRole());
		if(user.getRole().equals("Admin")) {
			mongoTemplate.save(user);
			mongoTemplate.remove(user);
			return user;
		}
		else if(user.getRole().equals("SuperUser")) {
			mongoTemplate.save(user);
			mongoTemplate.remove(user);
			return user;
		}
		else if(user.getRole().equals("Cashier")) {
			mongoTemplate.save(user);
			mongoTemplate.remove(user);
			return user;
		}
		
		return mongoTemplate.insert(user);
	}
	
	public boolean validateUserLogin(Long mobile, String password) {
		boolean flag=false;
		List<UserRegister> userlist=mongoTemplate.findAll(UserRegister.class);
		System.out.println(userlist);
		for(UserRegister ud:userlist)
		{ 
		if(ud.getMobileNo().equals(mobile)) {
		if(ud.getPassword().equalsIgnoreCase(password)) {
		flag=true;
		}
		}
		} 
		return flag;
		}

	@Override
	public boolean validateMobileandAnswer(Long mobileno, String answer) {
		
		boolean flag=false;
		List<UserRegister> userlist=mongoTemplate.findAll(UserRegister.class);
		System.out.println(userlist);
		for(UserRegister ud:userlist)
		{ 
		if(ud.getMobileNo().equals(mobileno)) {
		if(ud.getAnswer().equalsIgnoreCase(answer)) {
		flag=true;
		}
		}
		} 
		return flag;
		}
	@Override
	public void updatepassword(Long mobile, String pwd) {
		System.out.println("befor"+pwd);
		List<UserRegister> userlist=mongoTemplate.findAll(UserRegister.class);
		System.out.println(userlist);
		for(UserRegister ud:userlist)
		{ 
		if(ud.getMobileNo().equals(mobile)) {
			ud.setPassword(pwd);
			System.out.println(ud.getPassword());
			mongoTemplate.save(ud);
		}
		} 
	}
	@Override
	public String getAdminndSuperUserDetails(Long mobile, String password) {
		System.out.println("entered"+password);
		String role="";
		List<UserRegister> userlist=mongoTemplate.findAll(UserRegister.class);
		System.out.println(userlist);
		for(UserRegister ud:userlist)
		{ 
		if(ud.getMobileNo().equals(mobile)) {
			if(ud.getPassword().equalsIgnoreCase(password)) {
				role=ud.getRole();
				System.out.println("in dao"+role);
		}
		} 
	}
		return role;
	}

	@Override
	public List<UserRegister> getAllUserDeatils() {
		
		return mongoTemplate.findAll(UserRegister.class);
	}

	@Override
	public void deleteUser(Long mobileNo) {
		
		  List<UserRegister> userlist=mongoTemplate.findAll(UserRegister.class);
		  for(UserRegister ud:userlist) { 
		   if(ud.getMobileNo().equals(mobileNo)) {
			   System.out.println("haoi"); 
			   System.out.println(ud); 
			   mongoTemplate.remove(ud);
			  
		   } 
		  }
		 
		
	}

	
	
	

}
